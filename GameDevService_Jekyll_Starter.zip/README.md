# GameDevService Jekyll Starter

## Setup
1. Fork or upload this repo to GitHub.
2. Enable GitHub Pages in repo settings.
3. Set custom domain in settings.
4. Edit `_config.yml` to update your info.

## Structure
- Home: index.html
- About: about.html
- Services: services/
- Blog: blog/
- Contact: contact.html
- 404: 404.html

Edit content in each page as needed.